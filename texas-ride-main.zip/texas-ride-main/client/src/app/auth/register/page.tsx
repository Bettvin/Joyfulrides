import RegisterForm from '@/components/auth/register-form';

const page = () => {
  return (
    <RegisterForm />
  )
}

export default page