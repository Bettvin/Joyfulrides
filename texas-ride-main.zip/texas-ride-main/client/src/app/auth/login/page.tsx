import LoginForm from '@/components/auth/login-form';

const page = () => {
  return (
    <LoginForm />
  )
}

export default page