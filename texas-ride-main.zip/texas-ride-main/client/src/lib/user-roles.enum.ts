export enum USER_ROLE {
    RIDER ='rider',
    DRIVER ='driver'
}