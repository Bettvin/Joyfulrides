import React from "react";

export const Logo =() =>{
    <img src="/static/logo.png" alt="Logo"/>
}
